﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Final_Project
{
    public partial class Form2 : Form
    {
        //
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-8AQ53BR\\SQLEXPRESS;Initial Catalog=SkillsInternational;Integrated Security=True");
        public Form2()
        {
            InitializeComponent();
        }
        private void fillcombo()
        {
            //

            SqlDataAdapter da = new SqlDataAdapter("select regNo from Student ", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            cmbRegNo.DataSource = dt;
            cmbRegNo.DisplayMember = "regNo";
            cmbRegNo.ValueMember = "regNo";

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            //
            fillcombo();
        }
        private void Clear()
        {
            //

            txtFirstName.Clear();
            txtLastName.Clear();
            rbtnMale.Checked = false;
            rbtnFemale.Checked = false;
            txtAddress.Clear();
            txtEmail.Clear();
            txtMobilePhone.Clear();
            txtHomePhone.Clear();
            txtParentName.Clear();
            txtNIC.Clear();
            txtContactNo.Clear();

            cmbRegNo.Focus();
        }
        private void cmbRegNo_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedRegNo = cmbRegNo.SelectedItem.ToString();

            string gender;


            //

            string sqlSearch;
            sqlSearch = "select * from Student where regNo= '" + cmbRegNo.Text + "'  ";
            SqlCommand cmd = new SqlCommand(sqlSearch, con);
            cmd.Parameters.AddWithValue("@RegNo", selectedRegNo);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                txtFirstName.Text = dr["firstName"].ToString();
                txtLastName.Text = dr["lastName"].ToString();

                DateTime dob;
                if (DateTime.TryParse(dr["dateOfBirth"].ToString(), out dob))
                {
                    dtpDateOfBirth.Value = dob;
                }
                else
                {
                    // 
                }


                gender = dr["gender"].ToString();

                if (gender == "Male")
                {
                    rbtnMale.Checked = true;
                }

                else
                {
                    rbtnFemale.Checked = true;

                }


                txtAddress.Text = dr["address"].ToString();
                txtEmail.Text = dr["email"].ToString();
                txtMobilePhone.Text = dr["mobilePhone"].ToString();
                txtHomePhone.Text = dr["homePhone"].ToString();
                txtParentName.Text = dr["parentName"].ToString();
                txtNIC.Text = dr["nic"].ToString();
                txtContactNo.Text = dr["contactNo"].ToString();

            }
            
            con.Close();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            string gender;
            if (rbtnMale.Checked==true)
            {
                gender = "Male";
            }
            else
            {
                gender = "Female";
            }
            //
            DateTime DOB;
            DOB = Convert.ToDateTime(dtpDateOfBirth.Value);

            string sqlInsert;
            sqlInsert = "insert into Student (regNo ,firstName ,lastName ,dateOfBirth ,gender ,address ,email,mobilePhone,homePhone,parentName ,nic ,contactNo)values('" + cmbRegNo.Text + "','" + txtFirstName.Text + "','" + txtLastName.Text + "','" + DOB + "','" + gender + "','" + txtAddress.Text + "','" + txtEmail.Text + "','" + txtMobilePhone.Text + "','" + txtHomePhone.Text + "','" + txtParentName.Text + "','" + txtNIC.Text + "','" + txtContactNo.Text + "')";
            SqlCommand cmd = new SqlCommand(sqlInsert, con);
            con.Open();
            cmd.ExecuteNonQuery();
            MessageBox.Show("Record Added Succesfully","Register Student", MessageBoxButtons.OK, MessageBoxIcon.Information);
            Clear();
            con.Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string gender;
            if (rbtnMale.Checked == true)
            {
                gender = "Male";
            }
            else
            {
                gender = "Female";
            }

            DateTime DOB;
            DOB = Convert.ToDateTime(dtpDateOfBirth.Value);

            //
            string sqlUpdate;
            sqlUpdate = "update Student set firstName='" + txtFirstName.Text + "',lastName='" + txtLastName.Text + "', dateOfBirth='" + DOB + "' , gender='" + gender + "',address='" + txtAddress.Text + "',email='" + txtEmail.Text + "',mobilePhone='" + txtMobilePhone.Text + "',homePhone='" + txtHomePhone.Text + "',parentName='" + txtParentName.Text + "',nic='" + txtNIC.Text + "',contactNo='" + txtContactNo.Text + "'    where regNo='" + cmbRegNo.Text + "'  ";
            SqlCommand cmd = new SqlCommand(sqlUpdate, con);
            con.Open();
            cmd.ExecuteNonQuery();
            MessageBox.Show("Record Updated Succesfully", "Update Student", MessageBoxButtons.OK, MessageBoxIcon.Information);
            Clear();
            con.Close();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            //
            DialogResult ans;
            ans = (MessageBox.Show("Are you sure, Do you really want to Delete this Record...?", "Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question));
            if (ans == DialogResult.Yes)

            {
                string sqlDelete;
                sqlDelete = "delete from Student where regNo='" + cmbRegNo.Text + "' ";
                SqlCommand cmd = new SqlCommand(sqlDelete, con);
                con.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record Deleted Succesfully", "Delete Student", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clear();
                con.Close();
            }
            else
                Clear();
        }

        private void lnkExit_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Application.Exit();
        }

        private void lnkLogout_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

            Form1 loginForm = new Form1();
            loginForm.Show();
            this.Hide();
        }
    }
}
