﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Final_Project
{
    
    public partial class Form1 : Form
    {
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-8AQ53BR\\SQLEXPRESS;Initial Catalog=SkillsInternational;Integrated Security=True");
        public Form1()
        {
            InitializeComponent();
        }
        private void Clear()
        {

            txtUsername.Clear();
            txtPassword.Clear();
            txtUsername.Focus();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username, password;

            username = txtUsername.Text;
            password = txtPassword.Text;

            try
            {
                string querry = "SELECT* FROM Logins where username=  '" + txtUsername.Text + "' and password= '" + txtPassword.Text + "'";
                SqlCommand cmd = new SqlCommand(querry, con);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.Read() == true)
                {
                    username = txtUsername.Text;
                    password = txtPassword.Text;

                    Form2 form2 = new Form2();
                    form2.Show();
                    this.Hide();
                }

                else
                {
                    MessageBox.Show("Invalid Login credentials, please check Username and Password and try again", "Invalid login details", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Clear();

                }
            }
            catch
            {
                MessageBox.Show("Invalid login credentials,please check Username and Password and try again", "Invalid login details", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                con.Close();

            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
